NotesHub Raisoni - APK build steps (all free, no Android Studio)

1. SUPABASE (shared storage)
   - supabase.com -> sign up -> New project.
   - SQL Editor -> paste setup.sql -> Run.
   - Project Settings -> API: copy "Project URL" and "anon public" key.
   - Paste both into www/config.js.

2. GITHUB (builds the APK)
   - github.com -> New repository (public or private).
   - Upload ALL files of this folder (including the hidden .github folder).
   - Open the Actions tab -> "Build APK" runs automatically (~5 min).
   - Open the finished run -> Artifacts -> NotesHub-Raisoni-apk -> download, unzip.

3. PHONE
   - Send app-debug.apk to your phone, tap it, allow "Install unknown apps".
