// Paste your Supabase values here (Project Settings -> API)
window.SUPABASE_URL = "PASTE_YOUR_PROJECT_URL";
window.SUPABASE_ANON_KEY = "PASTE_YOUR_ANON_PUBLIC_KEY";
