-- Run once in Supabase -> SQL Editor
create table notes(
  id uuid primary key default gen_random_uuid(),
  title text not null, author text, subject text not null,
  file_name text, size bigint, url text not null,
  created_at timestamptz default now());
alter table notes enable row level security;
create policy "anyone reads" on notes for select using (true);
create policy "anyone adds" on notes for insert with check (true);

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('pdfs','pdfs',true,20971520,array['application/pdf']);
create policy "pdf read" on storage.objects for select using (bucket_id='pdfs');
create policy "pdf upload" on storage.objects for insert with check (bucket_id='pdfs');
